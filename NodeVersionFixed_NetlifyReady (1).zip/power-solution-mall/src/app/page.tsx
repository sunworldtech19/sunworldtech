'use client'

import { Phone, Mail, MapPin, Facebook, Twitter, Instagram, Youtube, Search, ShoppingCart, User, Star, MessageCircle, Send, Calculator, Zap, Shield, Award, CheckCircle, ArrowRight, Plus, Minus, Menu, X } from 'lucide-react'
import { useState, useEffect } from 'react'

interface Appliance {
  name: string
  quantity: number
  watts: number
  hours: number
}

export default function Home() {
  // Solar Calculator State
  const [appliances, setAppliances] = useState<Appliance[]>([
    { name: 'LED Lights (10W)', quantity: 5, watts: 10, hours: 8 },
    { name: 'Ceiling Fan (60W)', quantity: 3, watts: 60, hours: 10 },
    { name: 'Television (100W)', quantity: 1, watts: 100, hours: 6 },
    { name: 'Refrigerator (150W)', quantity: 1, watts: 150, hours: 24 }
  ])

  const [showCalculator, setShowCalculator] = useState(true)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [scrollProgress, setScrollProgress] = useState(0)

  // Track scroll progress
  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY
      const docHeight = document.documentElement.scrollHeight - window.innerHeight
      const progress = (scrollTop / docHeight) * 100
      setScrollProgress(progress)
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const addAppliance = () => {
    setAppliances([...appliances, { name: 'New Appliance', quantity: 1, watts: 100, hours: 5 }])
  }

  const updateAppliance = (index: number, field: keyof Appliance, value: string | number) => {
    const updated = [...appliances]
    if (typeof value === 'string' && field !== 'name') {
      updated[index][field] = parseInt(value) || 0
    } else {
      updated[index][field] = value as never
    }
    setAppliances(updated)
  }

  const removeAppliance = (index: number) => {
    setAppliances(appliances.filter((_, i) => i !== index))
  }

  const calculateLoad = () => {
    const totalWattHours = appliances.reduce((sum, item) =>
      sum + (item.quantity * item.watts * item.hours), 0
    )
    const dailyKWh = totalWattHours / 1000
    const recommendedBatteryAh = (totalWattHours / 12) * 1.3 // 30% safety margin
    const recommendedSolarPanels = Math.ceil(dailyKWh / 5) // Assuming 5 peak sun hours
    const recommendedInverter = Math.ceil(appliances.reduce((max, item) =>
      Math.max(max, item.quantity * item.watts), 0) / 1000) // Convert to KVA

    return {
      totalWattHours,
      dailyKWh,
      recommendedBatteryAh,
      recommendedSolarPanels,
      recommendedInverter
    }
  }

  const results = calculateLoad()

  return (
    <div className="min-h-screen bg-white">
      {/* Scroll Progress Indicator */}
      <div className="fixed top-0 left-0 w-full h-1 bg-gray-200 z-50">
        <div
          className="h-full bg-gradient-to-r from-purple-600 to-purple-700 transition-all duration-300"
          style={{ width: `${scrollProgress}%` }}
        ></div>
      </div>
      {/* Top Contact Bar */}
      <div className="bg-purple-600 text-white py-2 px-4">
        <div className="container mx-auto flex flex-wrap justify-between items-center text-sm">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <Phone size={14} />
              <span>08168216308</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone size={14} />
              <span>09028354365</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin size={14} />
              <span>5 Oyetubo Street, Ikeja, Lagos</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail size={14} />
              <span>sunworldtech19@gmail.com</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Twitter size={16} className="hover:text-purple-300 cursor-pointer transition-colors" />
            <Facebook size={16} className="hover:text-purple-300 cursor-pointer transition-colors" />
            <Instagram size={16} className="hover:text-purple-300 cursor-pointer transition-colors" />
            <Youtube size={16} className="hover:text-purple-300 cursor-pointer transition-colors" />
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header className="bg-white shadow-md sticky top-1 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center">
              <h1 className="text-xl md:text-2xl font-bold text-purple-600">
                <span className="text-purple-600">Sunworld</span>
                <span className="text-gray-800">Tech</span>
                <span className="text-purple-600">Support</span>
              </h1>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center space-x-8">
              <a href="#" className="text-gray-700 hover:text-purple-600 font-medium transition-colors">Inverter</a>
              <a href="#" className="text-gray-700 hover:text-purple-600 font-medium transition-colors">Batteries</a>
              <a href="#" className="text-gray-700 hover:text-purple-600 font-medium transition-colors">Solar</a>
              <a href="#" className="text-gray-700 hover:text-purple-600 font-medium transition-colors">Stabilizer</a>
              <a href="#" className="text-gray-700 hover:text-purple-600 font-medium transition-colors">UPS</a>
              <a href="#calculator" className="text-gray-700 hover:text-purple-600 font-medium transition-colors">Calculator</a>
              <a href="#" className="text-gray-700 hover:text-purple-600 font-medium transition-colors">Resources</a>
              <a href="#contact" className="text-gray-700 hover:text-purple-600 font-medium transition-colors">Contact</a>
            </nav>

            {/* Desktop Search and Actions */}
            <div className="hidden md:flex items-center gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                <input
                  type="text"
                  placeholder="Search products..."
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all w-48 lg:w-64"
                />
              </div>
              <button className="p-2 text-gray-600 hover:text-purple-600 transition-colors">
                <User size={20} />
              </button>
              <button className="p-2 text-gray-600 hover:text-purple-600 transition-colors">
                <ShoppingCart size={20} />
              </button>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-gray-600 hover:text-purple-600 transition-colors"
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="lg:hidden mt-4 pb-4 border-t border-gray-200 animate-fade-in">
              <nav className="flex flex-col space-y-4 mt-4">
                <a href="#" className="text-gray-700 hover:text-purple-600 font-medium transition-colors py-2">Inverter</a>
                <a href="#" className="text-gray-700 hover:text-purple-600 font-medium transition-colors py-2">Batteries</a>
                <a href="#" className="text-gray-700 hover:text-purple-600 font-medium transition-colors py-2">Solar</a>
                <a href="#" className="text-gray-700 hover:text-purple-600 font-medium transition-colors py-2">Stabilizer</a>
                <a href="#" className="text-gray-700 hover:text-purple-600 font-medium transition-colors py-2">UPS</a>
                <a href="#calculator" className="text-gray-700 hover:text-purple-600 font-medium transition-colors py-2" onClick={() => setMobileMenuOpen(false)}>Calculator</a>
                <a href="#" className="text-gray-700 hover:text-purple-600 font-medium transition-colors py-2">Resources</a>
                <a href="#contact" className="text-gray-700 hover:text-purple-600 font-medium transition-colors py-2" onClick={() => setMobileMenuOpen(false)}>Contact</a>
              </nav>

              {/* Mobile Search */}
              <div className="mt-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                  <input
                    type="text"
                    placeholder="Search products..."
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                  />
                </div>
              </div>

              {/* Mobile Actions */}
              <div className="flex gap-4 mt-4">
                <button className="flex-1 bg-purple-600 hover:bg-purple-700 text-white py-2 px-4 rounded-lg transition-colors">
                  Account
                </button>
                <button className="flex-1 bg-gray-600 hover:bg-gray-700 text-white py-2 px-4 rounded-lg transition-colors">
                  Cart (0)
                </button>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section with Real Background */}
      <section className="relative bg-gradient-to-r from-purple-600 to-purple-700 text-white py-20 overflow-hidden">
        {/* Real Background Image */}
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1509391366360-2e959784a276?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2072&q=80")'
          }}
        ></div>

        {/* Animated Background Elements */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-32 h-32 border border-white rounded-full animate-pulse"></div>
          <div className="absolute top-32 right-20 w-24 h-24 border border-white rounded-full animate-bounce"></div>
          <div className="absolute bottom-20 left-1/4 w-16 h-16 border border-white rounded-full animate-ping"></div>
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="flex flex-col lg:flex-row items-center">
            <div className="lg:w-1/2 mb-8 lg:mb-0">
              <div className="inline-block bg-purple-500 text-white px-4 py-2 rounded-full text-sm font-semibold mb-4 animate-bounce">
                🔧 Professional Solar Installation Services
              </div>
              <h2 className="text-5xl font-bold mb-6 leading-tight animate-fade-in">
                Go Solar Without<br />the Upfront Cost!
              </h2>
              <p className="text-xl mb-8 leading-relaxed">
                Nigeria's #1 Solar Energy Company. Get reliable power solutions with flexible payment plans, professional installation, and 24/7 support.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mb-6">
                <button className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-lg font-semibold text-lg transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl">
                  Get Free Quote
                </button>
                <button
                  onClick={() => setShowCalculator(!showCalculator)}
                  className="bg-green-500 hover:bg-green-600 text-white px-8 py-3 rounded-lg font-semibold text-lg transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl flex items-center gap-2"
                >
                  <Calculator size={20} />
                  Solar Calculator
                </button>
              </div>

              {/* Trust Badges */}
              <div className="flex items-center gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-green-400" />
                  <span>Licensed & Insured</span>
                </div>
                <div className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-yellow-400" />
                  <span>5-Year Warranty</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-blue-400" />
                  <span>1000+ Installations</span>
                </div>
              </div>
            </div>

            <div className="lg:w-1/2 flex justify-center">
              <div className="bg-white bg-opacity-10 p-8 rounded-lg backdrop-blur-sm animate-float">
                <div className="text-center">
                  <div className="w-64 h-64 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center mb-4 shadow-2xl animate-pulse relative overflow-hidden">
                    <img
                      src="https://images.unsplash.com/photo-1559302504-64aae6ca6b6d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
                      alt="Solar Installation Team"
                      className="w-full h-full object-cover rounded-full"
                    />
                    <div className="absolute inset-0 bg-purple-600 opacity-30 rounded-full"></div>
                  </div>
                  <p className="text-lg font-semibold">Professional Installation Team</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Solar System Calculator */}
      {showCalculator && (
        <section id="calculator" className="py-16 bg-gradient-to-br from-blue-50 to-purple-50">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-gray-800 mb-4 flex items-center justify-center gap-3">
                  <Calculator className="w-8 h-8 text-purple-600" />
                  Solar System Calculator
                </h2>
                <p className="text-gray-600">Calculate your solar power requirements and get instant recommendations</p>
              </div>

              <div className="grid lg:grid-cols-2 gap-8">
                {/* Calculator Input */}
                <div className="bg-white p-6 rounded-lg shadow-lg">
                  <h3 className="text-xl font-semibold mb-6 text-gray-800">Your Electrical Appliances</h3>

                  <div className="space-y-4 max-h-96 overflow-y-auto">
                    {appliances.map((appliance, index) => (
                      <div key={index} className="border border-gray-200 p-4 rounded-lg">
                        <div className="grid grid-cols-2 gap-4 mb-3">
                          <input
                            type="text"
                            value={appliance.name}
                            onChange={(e) => updateAppliance(index, 'name', e.target.value)}
                            className="border border-gray-300 rounded px-3 py-2 text-sm"
                            placeholder="Appliance name"
                          />
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => removeAppliance(index)}
                              className="text-red-500 hover:text-red-700 p-1"
                            >
                              <Minus size={16} />
                            </button>
                          </div>
                        </div>

                        <div className="grid grid-cols-3 gap-2">
                          <div>
                            <label className="text-xs text-gray-600">Quantity</label>
                            <input
                              type="number"
                              value={appliance.quantity}
                              onChange={(e) => updateAppliance(index, 'quantity', parseInt(e.target.value) || 0)}
                              className="w-full border border-gray-300 rounded px-2 py-1 text-sm"
                              min="1"
                            />
                          </div>
                          <div>
                            <label className="text-xs text-gray-600">Watts</label>
                            <input
                              type="number"
                              value={appliance.watts}
                              onChange={(e) => updateAppliance(index, 'watts', parseInt(e.target.value) || 0)}
                              className="w-full border border-gray-300 rounded px-2 py-1 text-sm"
                              min="1"
                            />
                          </div>
                          <div>
                            <label className="text-xs text-gray-600">Hours/Day</label>
                            <input
                              type="number"
                              value={appliance.hours}
                              onChange={(e) => updateAppliance(index, 'hours', parseInt(e.target.value) || 0)}
                              className="w-full border border-gray-300 rounded px-2 py-1 text-sm"
                              min="1"
                              max="24"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <button
                    onClick={addAppliance}
                    className="w-full mt-4 bg-purple-600 hover:bg-purple-700 text-white py-2 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
                  >
                    <Plus size={16} />
                    Add Appliance
                  </button>
                </div>

                {/* Calculator Results */}
                <div className="bg-gradient-to-br from-purple-600 to-purple-700 text-white p-6 rounded-lg shadow-lg">
                  <h3 className="text-xl font-semibold mb-6">Recommended System</h3>

                  <div className="space-y-6">
                    <div className="bg-white bg-opacity-20 p-4 rounded-lg">
                      <h4 className="font-semibold mb-2">Daily Energy Consumption</h4>
                      <p className="text-2xl font-bold">{results.dailyKWh.toFixed(2)} kWh</p>
                      <p className="text-sm opacity-80">{results.totalWattHours.toFixed(0)} Watt-hours</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-white bg-opacity-20 p-3 rounded-lg">
                        <h4 className="font-semibold mb-1 text-sm">Solar Panels</h4>
                        <p className="text-xl font-bold">{results.recommendedSolarPanels}</p>
                        <p className="text-xs opacity-80">300W panels</p>
                      </div>

                      <div className="bg-white bg-opacity-20 p-3 rounded-lg">
                        <h4 className="font-semibold mb-1 text-sm">Inverter</h4>
                        <p className="text-xl font-bold">{results.recommendedInverter}KVA</p>
                        <p className="text-xs opacity-80">Pure sine wave</p>
                      </div>

                      <div className="bg-white bg-opacity-20 p-3 rounded-lg">
                        <h4 className="font-semibold mb-1 text-sm">Battery Bank</h4>
                        <p className="text-xl font-bold">{Math.ceil(results.recommendedBatteryAh)}Ah</p>
                        <p className="text-xs opacity-80">12V deep cycle</p>
                      </div>

                      <div className="bg-white bg-opacity-20 p-3 rounded-lg">
                        <h4 className="font-semibold mb-1 text-sm">Estimated Cost</h4>
                        <p className="text-xl font-bold">₦{(results.dailyKWh * 500000).toLocaleString()}</p>
                        <p className="text-xs opacity-80">Complete system</p>
                      </div>
                    </div>

                    <button className="w-full bg-orange-500 hover:bg-orange-600 text-white py-3 px-4 rounded-lg font-semibold transition-colors">
                      Get Detailed Quote
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Installation Process Section */}
      <section className="py-16 bg-white relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-50 to-blue-50 opacity-50"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Our Installation Process</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">From initial consultation to system commissioning, we ensure a seamless solar installation experience</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            <div className="text-center group">
              <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full mx-auto mb-4 flex items-center justify-center text-white font-bold text-xl group-hover:scale-110 transition-transform duration-300 shadow-lg">
                1
              </div>
              <h3 className="font-semibold text-lg mb-2 text-gray-800">Site Assessment</h3>
              <p className="text-gray-600 text-sm">Free on-site evaluation to determine your property's solar potential and energy requirements</p>
            </div>

            <div className="text-center group">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full mx-auto mb-4 flex items-center justify-center text-white font-bold text-xl group-hover:scale-110 transition-transform duration-300 shadow-lg">
                2
              </div>
              <h3 className="font-semibold text-lg mb-2 text-gray-800">Custom Design</h3>
              <p className="text-gray-600 text-sm">Tailored system design with 3D modeling and detailed energy production projections</p>
            </div>

            <div className="text-center group">
              <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-green-600 rounded-full mx-auto mb-4 flex items-center justify-center text-white font-bold text-xl group-hover:scale-110 transition-transform duration-300 shadow-lg">
                3
              </div>
              <h3 className="font-semibold text-lg mb-2 text-gray-800">Professional Installation</h3>
              <p className="text-gray-600 text-sm">Certified technicians install your system with precision, safety, and minimal disruption</p>
            </div>

            <div className="text-center group">
              <div className="w-20 h-20 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full mx-auto mb-4 flex items-center justify-center text-white font-bold text-xl group-hover:scale-110 transition-transform duration-300 shadow-lg">
                4
              </div>
              <h3 className="font-semibold text-lg mb-2 text-gray-800">System Commissioning</h3>
              <p className="text-gray-600 text-sm">Thorough testing, system activation, and comprehensive training on system operation</p>
            </div>
          </div>

          {/* Installation Gallery */}
          <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-2xl p-8 text-white">
            <h3 className="text-2xl font-bold text-center mb-8">Recent Installations</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="relative group cursor-pointer">
                <img
                  src="https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
                  alt="Residential Solar Installation"
                  className="w-full h-48 object-cover rounded-lg transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black bg-opacity-40 rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="text-center">
                    <h4 className="font-semibold">5KVA Residential System</h4>
                    <p className="text-sm">Lagos, Nigeria</p>
                  </div>
                </div>
              </div>

              <div className="relative group cursor-pointer">
                <img
                  src="https://images.unsplash.com/photo-1466611653911-95081537e5b7?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
                  alt="Commercial Solar Installation"
                  className="w-full h-48 object-cover rounded-lg transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black bg-opacity-40 rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="text-center">
                    <h4 className="font-semibold">15KVA Commercial System</h4>
                    <p className="text-sm">Abuja, Nigeria</p>
                  </div>
                </div>
              </div>

              <div className="relative group cursor-pointer">
                <img
                  src="https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
                  alt="Industrial Solar Installation"
                  className="w-full h-48 object-cover rounded-lg transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black bg-opacity-40 rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="text-center">
                    <h4 className="font-semibold">50KVA Industrial System</h4>
                    <p className="text-sm">Port Harcourt, Nigeria</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="text-center mt-6">
              <button className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg transition-colors">
                View All Projects
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Why Choose Sunworld Tech Support?</h2>
            <p className="text-gray-600">Nigeria's most trusted solar energy company</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center group hover:transform hover:scale-105 transition-all duration-300">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-purple-200 transition-colors">
                <span className="text-2xl">💰</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Flexible Payment Plans!</h3>
              <p className="text-gray-600">0% down payment options available. Pay as low as ₦50,000 monthly for complete solar systems.</p>
            </div>
            <div className="text-center group hover:transform hover:scale-105 transition-all duration-300">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-purple-200 transition-colors">
                <span className="text-2xl">🛡️</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">5-Year Warranty</h3>
              <p className="text-gray-600">Comprehensive warranty on all components with free maintenance for the first year.</p>
            </div>
            <div className="text-center group hover:transform hover:scale-105 transition-all duration-300">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-purple-200 transition-colors">
                <span className="text-2xl">⚡</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">24/7 Power Backup!</h3>
              <p className="text-gray-600">Never experience power outage again with our advanced battery backup systems.</p>
            </div>
            <div className="text-center group hover:transform hover:scale-105 transition-all duration-300">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-purple-200 transition-colors">
                <span className="text-2xl">🔧</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Expert Installation!</h3>
              <p className="text-gray-600">Certified technicians with 10+ years experience in solar installations across Nigeria.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Financing Options Section */}
      <section className="py-16 bg-gradient-to-br from-purple-600 to-purple-700 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-32 h-32 border border-white rounded-full animate-spin-slow"></div>
          <div className="absolute bottom-20 right-20 w-24 h-24 border border-white rounded-full animate-bounce"></div>
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Flexible Payment Solutions</h2>
            <p className="text-purple-100 max-w-2xl mx-auto">Choose from our range of financing options designed to make solar energy accessible to everyone</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-xl p-6 hover:bg-opacity-20 transition-all duration-300 transform hover:-translate-y-2">
              <div className="text-center mb-4">
                <div className="w-16 h-16 bg-green-500 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-2xl">💳</span>
                </div>
                <h3 className="text-xl font-bold mb-2">0% Down Payment</h3>
                <p className="text-purple-100 text-sm mb-4">Start your solar journey today with no upfront costs</p>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span>System Size:</span>
                  <span className="font-semibold">5KVA</span>
                </div>
                <div className="flex justify-between">
                  <span>Monthly Payment:</span>
                  <span className="font-semibold text-green-300">₦85,000</span>
                </div>
                <div className="flex justify-between">
                  <span>Duration:</span>
                  <span className="font-semibold">36 months</span>
                </div>
                <div className="flex justify-between">
                  <span>Total Savings:</span>
                  <span className="font-semibold text-yellow-300">₦2.8M</span>
                </div>
              </div>
              <button className="w-full mt-6 bg-green-500 hover:bg-green-600 text-white py-2 px-4 rounded-lg transition-colors">
                Apply Now
              </button>
            </div>

            <div className="bg-white bg-opacity-15 backdrop-blur-sm rounded-xl p-6 hover:bg-opacity-25 transition-all duration-300 transform hover:-translate-y-2 border-2 border-yellow-400">
              <div className="text-center mb-4">
                <div className="bg-yellow-500 text-yellow-900 px-3 py-1 rounded-full text-xs font-bold mb-3 inline-block">MOST POPULAR</div>
                <div className="w-16 h-16 bg-yellow-500 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-2xl">⭐</span>
                </div>
                <h3 className="text-xl font-bold mb-2">Flexible Installments</h3>
                <p className="text-purple-100 text-sm mb-4">Pay in comfortable monthly installments over 2-5 years</p>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span>System Size:</span>
                  <span className="font-semibold">7.5KVA</span>
                </div>
                <div className="flex justify-between">
                  <span>Monthly Payment:</span>
                  <span className="font-semibold text-green-300">₦120,000</span>
                </div>
                <div className="flex justify-between">
                  <span>Duration:</span>
                  <span className="font-semibold">48 months</span>
                </div>
                <div className="flex justify-between">
                  <span>Total Savings:</span>
                  <span className="font-semibold text-yellow-300">₦4.2M</span>
                </div>
              </div>
              <button className="w-full mt-6 bg-yellow-500 hover:bg-yellow-600 text-yellow-900 py-2 px-4 rounded-lg transition-colors font-semibold">
                Get Quote
              </button>
            </div>

            <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-xl p-6 hover:bg-opacity-20 transition-all duration-300 transform hover:-translate-y-2">
              <div className="text-center mb-4">
                <div className="w-16 h-16 bg-blue-500 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-2xl">💰</span>
                </div>
                <h3 className="text-xl font-bold mb-2">Cash Purchase</h3>
                <p className="text-purple-100 text-sm mb-4">Get maximum savings with our cash purchase discount</p>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span>System Size:</span>
                  <span className="font-semibold">10KVA</span>
                </div>
                <div className="flex justify-between">
                  <span>Cash Price:</span>
                  <span className="font-semibold text-green-300">₦4,500,000</span>
                </div>
                <div className="flex justify-between">
                  <span>Discount:</span>
                  <span className="font-semibold text-yellow-300">15% OFF</span>
                </div>
                <div className="flex justify-between">
                  <span>Total Savings:</span>
                  <span className="font-semibold text-yellow-300">₦6.5M</span>
                </div>
              </div>
              <button className="w-full mt-6 bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded-lg transition-colors">
                Calculate Savings
              </button>
            </div>
          </div>

          <div className="text-center mt-12">
            <p className="text-purple-100 mb-4">Need a custom financing solution? We work with leading financial institutions.</p>
            <div className="flex justify-center gap-6 items-center text-sm">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-400" />
                <span>Pre-approved loans available</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-400" />
                <span>Low interest rates</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-400" />
                <span>Quick approval process</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Popular Categories */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Popular Categories</h2>
            <p className="text-gray-600 mb-8">Looking for top-notch products tailored to your needs? <strong>Explore Our Popular Product Categories!</strong></p>
            <button className="bg-purple-500 hover:bg-purple-600 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105">
              View More →
            </button>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-6">
            <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 text-center group">
              <div className="w-20 h-20 bg-gradient-to-br from-yellow-100 to-orange-100 rounded-full mx-auto mb-4 flex items-center justify-center group-hover:scale-110 transition-transform">
                <span className="text-2xl">☀️</span>
              </div>
              <h3 className="font-semibold text-lg mb-2">Solar Panels</h3>
              <p className="text-gray-500 text-sm">Premium monocrystalline panels</p>
              <p className="text-purple-600 font-semibold text-sm mt-2">From ₦85,000</p>
            </div>
            <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 text-center group">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-100 to-purple-100 rounded-full mx-auto mb-4 flex items-center justify-center group-hover:scale-110 transition-transform">
                <span className="text-2xl">🔋</span>
              </div>
              <h3 className="font-semibold text-lg mb-2">Inverters</h3>
              <p className="text-gray-500 text-sm">Pure sine wave inverters</p>
              <p className="text-purple-600 font-semibold text-sm mt-2">From ₦120,000</p>
            </div>
            <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 text-center group">
              <div className="w-20 h-20 bg-gradient-to-br from-green-100 to-emerald-100 rounded-full mx-auto mb-4 flex items-center justify-center group-hover:scale-110 transition-transform">
                <span className="text-2xl">🔌</span>
              </div>
              <h3 className="font-semibold text-lg mb-2">Batteries</h3>
              <p className="text-gray-500 text-sm">Deep cycle lithium batteries</p>
              <p className="text-purple-600 font-semibold text-sm mt-2">From ₦180,000</p>
            </div>
            <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 text-center group">
              <div className="w-20 h-20 bg-gradient-to-br from-purple-100 to-pink-100 rounded-full mx-auto mb-4 flex items-center justify-center group-hover:scale-110 transition-transform">
                <span className="text-2xl">⚡</span>
              </div>
              <h3 className="font-semibold text-lg mb-2">Stabilizers</h3>
              <p className="text-gray-500 text-sm">Automatic voltage regulators</p>
              <p className="text-purple-600 font-semibold text-sm mt-2">From ₦45,000</p>
            </div>
            <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 text-center group">
              <div className="w-20 h-20 bg-gradient-to-br from-red-100 to-orange-100 rounded-full mx-auto mb-4 flex items-center justify-center group-hover:scale-110 transition-transform">
                <span className="text-2xl">📦</span>
              </div>
              <h3 className="font-semibold text-lg mb-2">Complete Systems</h3>
              <p className="text-gray-500 text-sm">Ready-to-install packages</p>
              <p className="text-purple-600 font-semibold text-sm mt-2">From ₦850,000</p>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Countdown Timer */}
      <section className="py-12 bg-gradient-to-r from-purple-600 to-purple-700 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-20"></div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <h3 className="text-3xl font-bold mb-4 animate-pulse">🔥 New Year Special Offer! 🔥</h3>
          <p className="mb-6 text-lg">Get up to 30% discount on complete solar systems. Limited time only!</p>
          <div className="flex justify-center gap-4 mb-6">
            <div className="bg-purple-500 px-6 py-4 rounded-lg shadow-lg transform hover:scale-105 transition-transform">
              <div className="text-4xl font-bold animate-bounce">07</div>
              <div className="text-sm">DAYS</div>
            </div>
            <div className="bg-purple-500 px-6 py-4 rounded-lg shadow-lg transform hover:scale-105 transition-transform">
              <div className="text-4xl font-bold animate-bounce">15</div>
              <div className="text-sm">HOURS</div>
            </div>
            <div className="bg-purple-500 px-6 py-4 rounded-lg shadow-lg transform hover:scale-105 transition-transform">
              <div className="text-4xl font-bold animate-bounce">32</div>
              <div className="text-sm">MINUTES</div>
            </div>
            <div className="bg-purple-500 px-6 py-4 rounded-lg shadow-lg transform hover:scale-105 transition-transform">
              <div className="text-4xl font-bold animate-pulse">45</div>
              <div className="text-sm">SECONDS</div>
            </div>
          </div>
          <button className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg">
            Claim Your Discount Now!
          </button>
        </div>
      </section>

      {/* Best Selling Products with Real Images */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Best Selling Products!</h2>
            <p className="text-gray-600">Explore our Weekly best-selling products & Discover top-rated items from our featured collection.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 group">
              <div className="h-48 bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center relative overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1509391366360-2e959784a276?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
                  alt="Solar Panel System"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-purple-500 opacity-0 group-hover:opacity-10 transition-opacity duration-300"></div>
              </div>
              <div className="p-4">
                <span className="text-xs bg-gradient-to-r from-orange-500 to-red-500 text-white px-2 py-1 rounded-full animate-pulse">HOT SALE!</span>
                <p className="text-sm text-gray-500 mt-2 font-medium">SOLAR SYSTEM</p>
                <h3 className="font-semibold mb-2 text-gray-800">5KVA Complete Solar System Package</h3>
                <div className="flex items-center gap-2">
                  <span className="text-lg font-bold text-purple-600">₦2,850,000</span>
                  <span className="text-sm text-gray-400 line-through">₦3,200,000</span>
                </div>
                <div className="mt-3 flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                  <span className="text-sm text-gray-500 ml-1">(4.9)</span>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 group">
              <div className="h-48 bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center relative overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
                  alt="Inverter"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-purple-500 opacity-0 group-hover:opacity-10 transition-opacity duration-300"></div>
              </div>
              <div className="p-4">
                <span className="text-xs bg-gradient-to-r from-green-500 to-emerald-500 text-white px-2 py-1 rounded-full">-21%</span>
                <p className="text-sm text-gray-500 mt-2 font-medium">INVERTER</p>
                <h3 className="font-semibold mb-2 text-gray-800">3.5KVA Pure Sine Wave Inverter</h3>
                <div className="flex items-center gap-2">
                  <span className="text-lg font-bold text-purple-600">₦485,000</span>
                  <span className="text-sm text-gray-400 line-through">₦615,000</span>
                </div>
                <div className="mt-3 flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                  <span className="text-sm text-gray-500 ml-1">(4.7)</span>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 group">
              <div className="h-48 bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center relative overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1615461066841-6116e61058f4?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
                  alt="Solar Batteries"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-purple-500 opacity-0 group-hover:opacity-10 transition-opacity duration-300"></div>
              </div>
              <div className="p-4">
                <span className="text-xs bg-gradient-to-r from-red-500 to-pink-500 text-white px-2 py-1 rounded-full">-18%</span>
                <p className="text-sm text-gray-500 mt-2 font-medium">LITHIUM BATTERY</p>
                <h3 className="font-semibold mb-2 text-gray-800">200Ah Lithium Battery Bank</h3>
                <div className="flex items-center gap-2">
                  <span className="text-lg font-bold text-purple-600">₦850,000</span>
                  <span className="text-sm text-gray-400 line-through">₦1,050,000</span>
                </div>
                <div className="mt-3 flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                  <span className="text-sm text-gray-500 ml-1">(4.8)</span>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 group">
              <div className="h-48 bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center relative overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
                  alt="Voltage Stabilizer"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-purple-500 opacity-0 group-hover:opacity-10 transition-opacity duration-300"></div>
              </div>
              <div className="p-4">
                <span className="text-xs bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-2 py-1 rounded-full">BESTSELLER</span>
                <p className="text-sm text-gray-500 mt-2 font-medium">VOLTAGE STABILIZER</p>
                <h3 className="font-semibold mb-2 text-gray-800">10KVA Automatic Voltage Stabilizer</h3>
                <div className="flex items-center gap-2">
                  <span className="text-lg font-bold text-purple-600">₦185,000</span>
                  <span className="text-sm text-gray-400 line-through">₦225,000</span>
                </div>
                <div className="mt-3 flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                  <span className="text-sm text-gray-500 ml-1">(4.6)</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Brand Showcase */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Trusted Brands We Work With</h2>
            <p className="text-gray-600">Premium quality products from world-renowned manufacturers</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8 items-center">
            <div className="bg-gray-50 p-6 rounded-lg hover:shadow-md transition-shadow">
              <div className="text-center">
                <div className="font-bold text-xl text-gray-800">Felicity</div>
                <div className="text-sm text-gray-500">Solar Inverters</div>
              </div>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg hover:shadow-md transition-shadow">
              <div className="text-center">
                <div className="font-bold text-xl text-gray-800">Mercury</div>
                <div className="text-sm text-gray-500">Batteries</div>
              </div>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg hover:shadow-md transition-shadow">
              <div className="text-center">
                <div className="font-bold text-xl text-gray-800">Luminous</div>
                <div className="text-sm text-gray-500">Solar Systems</div>
              </div>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg hover:shadow-md transition-shadow">
              <div className="text-center">
                <div className="font-bold text-xl text-gray-800">Prag</div>
                <div className="text-sm text-gray-500">Stabilizers</div>
              </div>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg hover:shadow-md transition-shadow">
              <div className="text-center">
                <div className="font-bold text-xl text-gray-800">Crown</div>
                <div className="text-sm text-gray-500">Micro Inverters</div>
              </div>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg hover:shadow-md transition-shadow">
              <div className="text-center">
                <div className="font-bold text-xl text-gray-800">Zektron</div>
                <div className="text-sm text-gray-500">UPS Systems</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Technical Specifications Comparison */}
      <section className="py-16 bg-gradient-to-br from-gray-50 to-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Compare Our Solar System Packages</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Choose the perfect solar solution based on your energy needs and budget</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full bg-white rounded-lg shadow-lg overflow-hidden">
              <thead className="bg-gradient-to-r from-purple-600 to-purple-700 text-white">
                <tr>
                  <th className="p-4 text-left">Specifications</th>
                  <th className="p-4 text-center">Basic 3KVA</th>
                  <th className="p-4 text-center bg-yellow-500 text-yellow-900 relative">
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-yellow-400 text-yellow-900 px-3 py-1 rounded-full text-xs font-bold">POPULAR</div>
                    Standard 5KVA
                  </th>
                  <th className="p-4 text-center">Premium 7.5KVA</th>
                  <th className="p-4 text-center">Enterprise 10KVA</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                <tr className="border-b hover:bg-gray-50">
                  <td className="p-4 font-semibold">Solar Panels</td>
                  <td className="p-4 text-center">6 x 300W Mono</td>
                  <td className="p-4 text-center bg-yellow-50">10 x 300W Mono</td>
                  <td className="p-4 text-center">15 x 300W Mono</td>
                  <td className="p-4 text-center">20 x 300W Mono</td>
                </tr>
                <tr className="border-b hover:bg-gray-50">
                  <td className="p-4 font-semibold">Inverter Capacity</td>
                  <td className="p-4 text-center">3KVA Pure Sine</td>
                  <td className="p-4 text-center bg-yellow-50">5KVA Pure Sine</td>
                  <td className="p-4 text-center">7.5KVA Pure Sine</td>
                  <td className="p-4 text-center">10KVA Pure Sine</td>
                </tr>
                <tr className="border-b hover:bg-gray-50">
                  <td className="p-4 font-semibold">Battery Bank</td>
                  <td className="p-4 text-center">4 x 100Ah Lithium</td>
                  <td className="p-4 text-center bg-yellow-50">6 x 100Ah Lithium</td>
                  <td className="p-4 text-center">8 x 100Ah Lithium</td>
                  <td className="p-4 text-center">10 x 100Ah Lithium</td>
                </tr>
                <tr className="border-b hover:bg-gray-50">
                  <td className="p-4 font-semibold">Daily Energy Output</td>
                  <td className="p-4 text-center">9-12 kWh</td>
                  <td className="p-4 text-center bg-yellow-50">15-18 kWh</td>
                  <td className="p-4 text-center">22-27 kWh</td>
                  <td className="p-4 text-center">30-36 kWh</td>
                </tr>
                <tr className="border-b hover:bg-gray-50">
                  <td className="p-4 font-semibold">Backup Time</td>
                  <td className="p-4 text-center">8-12 hours</td>
                  <td className="p-4 text-center bg-yellow-50">12-16 hours</td>
                  <td className="p-4 text-center">16-20 hours</td>
                  <td className="p-4 text-center">20-24 hours</td>
                </tr>
                <tr className="border-b hover:bg-gray-50">
                  <td className="p-4 font-semibold">Suitable For</td>
                  <td className="p-4 text-center">1-2 Bedroom Apt</td>
                  <td className="p-4 text-center bg-yellow-50">3-4 Bedroom House</td>
                  <td className="p-4 text-center">Large Home/Office</td>
                  <td className="p-4 text-center">Commercial/Industrial</td>
                </tr>
                <tr className="border-b hover:bg-gray-50">
                  <td className="p-4 font-semibold">Installation Time</td>
                  <td className="p-4 text-center">1 Day</td>
                  <td className="p-4 text-center bg-yellow-50">1-2 Days</td>
                  <td className="p-4 text-center">2-3 Days</td>
                  <td className="p-4 text-center">3-5 Days</td>
                </tr>
                <tr className="hover:bg-gray-50">
                  <td className="p-4 font-semibold text-lg">Total Investment</td>
                  <td className="p-4 text-center">
                    <div className="text-xl font-bold text-purple-600">₦1,850,000</div>
                    <div className="text-xs text-gray-500">₦51,000/month</div>
                  </td>
                  <td className="p-4 text-center bg-yellow-50">
                    <div className="text-xl font-bold text-purple-600">₦2,850,000</div>
                    <div className="text-xs text-gray-500">₦79,000/month</div>
                  </td>
                  <td className="p-4 text-center">
                    <div className="text-xl font-bold text-purple-600">₦4,250,000</div>
                    <div className="text-xs text-gray-500">₦118,000/month</div>
                  </td>
                  <td className="p-4 text-center">
                    <div className="text-xl font-bold text-purple-600">₦5,750,000</div>
                    <div className="text-xs text-gray-500">₦159,000/month</div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="text-center mt-8">
            <div className="flex flex-wrap justify-center gap-4">
              <button className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg transition-colors">
                Get Detailed Quote
              </button>
              <button className="border border-purple-600 text-purple-600 hover:bg-purple-50 px-6 py-3 rounded-lg transition-colors">
                Download Brochure
              </button>
              <button className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg transition-colors">
                Schedule Site Visit
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Service Areas Map */}
      <section className="py-16 bg-purple-600 text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Service Coverage Areas</h2>
            <p className="text-purple-100 max-w-2xl mx-auto">We provide professional solar installation and maintenance services across major cities in Nigeria</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white bg-opacity-10 rounded-lg p-6 hover:bg-opacity-20 transition-all duration-300">
              <h3 className="font-bold text-lg mb-3">Lagos State</h3>
              <ul className="space-y-1 text-purple-100 text-sm">
                <li>• Ikeja (Head Office)</li>
                <li>• Victoria Island</li>
                <li>• Lekki</li>
                <li>• Surulere</li>
                <li>• Ikoyi</li>
                <li>• Ajah</li>
              </ul>
              <div className="mt-4 text-xs">
                <span className="bg-green-500 text-white px-2 py-1 rounded">Next Day Service</span>
              </div>
            </div>

            <div className="bg-white bg-opacity-10 rounded-lg p-6 hover:bg-opacity-20 transition-all duration-300">
              <h3 className="font-bold text-lg mb-3">Federal Capital Territory</h3>
              <ul className="space-y-1 text-purple-100 text-sm">
                <li>• Abuja</li>
                <li>• Garki</li>
                <li>• Wuse</li>
                <li>• Maitama</li>
                <li>• Asokoro</li>
                <li>• Gwarinpa</li>
              </ul>
              <div className="mt-4 text-xs">
                <span className="bg-blue-500 text-white px-2 py-1 rounded">2-3 Days Service</span>
              </div>
            </div>

            <div className="bg-white bg-opacity-10 rounded-lg p-6 hover:bg-opacity-20 transition-all duration-300">
              <h3 className="font-bold text-lg mb-3">Other Major Cities</h3>
              <ul className="space-y-1 text-purple-100 text-sm">
                <li>• Port Harcourt</li>
                <li>• Kano</li>
                <li>• Ibadan</li>
                <li>• Benin City</li>
                <li>• Kaduna</li>
                <li>• Jos</li>
              </ul>
              <div className="mt-4 text-xs">
                <span className="bg-orange-500 text-white px-2 py-1 rounded">3-5 Days Service</span>
              </div>
            </div>
          </div>

          <div className="text-center mt-12">
            <p className="text-purple-100 mb-4">Don't see your location? We're expanding our coverage area!</p>
            <button className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 rounded-lg transition-colors">
              Request Service in Your Area
            </button>
          </div>
        </div>
      </section>

      {/* Customer Testimonials */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">What Our Customers Say</h2>
            <p className="text-gray-600">Over 1,000 satisfied customers across Nigeria</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-lg shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="flex items-center mb-4">
                <img
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
                  alt="Customer"
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div className="ml-4">
                  <h4 className="font-semibold text-gray-800">Adebayo Ogundimu</h4>
                  <p className="text-sm text-gray-500">Business Owner, Lagos</p>
                </div>
              </div>
              <div className="flex items-center mb-3">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <p className="text-gray-700 italic">"Exceptional service! My 5KVA solar system has been running perfectly for 8 months. No more NEPA bills and 24/7 power supply. Worth every penny!"</p>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-lg shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="flex items-center mb-4">
                <img
                  src="https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80"
                  alt="Customer"
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div className="ml-4">
                  <h4 className="font-semibold text-gray-800">Chioma Nwankwo</h4>
                  <p className="text-sm text-gray-500">Doctor, Abuja</p>
                </div>
              </div>
              <div className="flex items-center mb-3">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <p className="text-gray-700 italic">"Professional installation team and quality products. My clinic now runs 24/7 without interruptions. The payment plan made it very affordable!"</p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-lg shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="flex items-center mb-4">
                <img
                  src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
                  alt="Customer"
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div className="ml-4">
                  <h4 className="font-semibold text-gray-800">Emmanuel Okoro</h4>
                  <p className="text-sm text-gray-500">Engineer, Port Harcourt</p>
                </div>
              </div>
              <div className="flex items-center mb-3">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <p className="text-gray-700 italic">"Outstanding technical support! They designed a custom system for my manufacturing plant. Production has increased 40% with reliable power supply."</p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-800 mb-4">Frequently Asked Questions</h2>
              <p className="text-gray-600">Get answers to common questions about solar energy systems</p>
            </div>

            <div className="space-y-6">
              <div className="border border-gray-200 rounded-lg p-6">
                <h3 className="font-semibold text-lg text-gray-800 mb-3">How much can I save with solar energy?</h3>
                <p className="text-gray-600">Most customers save 80-95% on their electricity bills. A typical 5KVA system can save you ₦50,000-₦80,000 monthly on NEPA bills.</p>
              </div>

              <div className="border border-gray-200 rounded-lg p-6">
                <h3 className="font-semibold text-lg text-gray-800 mb-3">How long does installation take?</h3>
                <p className="text-gray-600">Most residential installations are completed within 1-2 days. Commercial systems may take 3-5 days depending on size and complexity.</p>
              </div>

              <div className="border border-gray-200 rounded-lg p-6">
                <h3 className="font-semibold text-lg text-gray-800 mb-3">What payment options are available?</h3>
                <p className="text-gray-600">We offer flexible payment plans including 0% down payment, monthly installments starting from ₦50,000, and outright purchase with discounts.</p>
              </div>

              <div className="border border-gray-200 rounded-lg p-6">
                <h3 className="font-semibold text-lg text-gray-800 mb-3">How long do solar systems last?</h3>
                <p className="text-gray-600">Our solar panels come with 25-year warranties, inverters have 5-10 year warranties, and lithium batteries last 10-15 years with proper maintenance.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Blog/News Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Latest Solar News & Tips</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Stay updated with the latest developments in solar technology and energy-saving tips</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <article className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 group">
              <div className="h-48 bg-gradient-to-br from-purple-100 to-purple-200 relative overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
                  alt="Solar Energy Nigeria"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4 bg-purple-600 text-white px-3 py-1 rounded-full text-xs font-bold">
                  ENERGY TIPS
                </div>
              </div>
              <div className="p-6">
                <div className="text-sm text-gray-500 mb-2">January 8, 2025 • 5 min read</div>
                <h3 className="font-bold text-lg mb-3 text-gray-800 group-hover:text-purple-600 transition-colors">
                  10 Ways to Reduce Your Electricity Bill in Nigeria
                </h3>
                <p className="text-gray-600 text-sm mb-4">
                  Discover practical strategies to cut your monthly electricity costs by up to 60% without compromising your comfort...
                </p>
                <button className="text-purple-600 hover:text-purple-700 font-semibold text-sm flex items-center gap-1 group">
                  Read More <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </article>

            <article className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 group">
              <div className="h-48 bg-gradient-to-br from-green-100 to-green-200 relative overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1548438294-1ad5d5f4f063?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
                  alt="Solar Panel Maintenance"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4 bg-green-600 text-white px-3 py-1 rounded-full text-xs font-bold">
                  MAINTENANCE
                </div>
              </div>
              <div className="p-6">
                <div className="text-sm text-gray-500 mb-2">January 5, 2025 • 7 min read</div>
                <h3 className="font-bold text-lg mb-3 text-gray-800 group-hover:text-purple-600 transition-colors">
                  Solar Panel Maintenance: Complete Guide for Nigerian Climate
                </h3>
                <p className="text-gray-600 text-sm mb-4">
                  Learn how to maintain your solar panels for optimal performance in Nigeria's tropical climate conditions...
                </p>
                <button className="text-purple-600 hover:text-purple-700 font-semibold text-sm flex items-center gap-1 group">
                  Read More <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </article>

            <article className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 group">
              <div className="h-48 bg-gradient-to-br from-yellow-100 to-orange-200 relative overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1613665813446-82a78c468a1d?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
                  alt="Solar Technology Innovation"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4 bg-orange-600 text-white px-3 py-1 rounded-full text-xs font-bold">
                  TECHNOLOGY
                </div>
              </div>
              <div className="p-6">
                <div className="text-sm text-gray-500 mb-2">January 3, 2025 • 6 min read</div>
                <h3 className="font-bold text-lg mb-3 text-gray-800 group-hover:text-purple-600 transition-colors">
                  Latest Solar Technology Innovations for 2025
                </h3>
                <p className="text-gray-600 text-sm mb-4">
                  Explore cutting-edge solar technologies that are making renewable energy more efficient and affordable...
                </p>
                <button className="text-purple-600 hover:text-purple-700 font-semibold text-sm flex items-center gap-1 group">
                  Read More <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </article>
          </div>

          <div className="text-center mt-12">
            <button className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3 rounded-lg transition-colors">
              View All Articles
            </button>
          </div>
        </div>
      </section>

      {/* Energy Monitoring Dashboard Preview */}
      <section className="py-16 bg-gradient-to-br from-gray-900 to-gray-800 text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Monitor Your Solar System Performance</h2>
            <p className="text-gray-300 max-w-2xl mx-auto">Track your energy production, consumption, and savings with our advanced monitoring system</p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="bg-gradient-to-br from-gray-800 to-gray-700 rounded-2xl p-8 shadow-2xl">
              <div className="grid md:grid-cols-3 gap-6 mb-8">
                <div className="bg-green-500 bg-opacity-20 border border-green-500 rounded-lg p-4 text-center">
                  <h3 className="text-sm font-semibold text-green-400 mb-2">TODAY'S PRODUCTION</h3>
                  <div className="text-3xl font-bold text-green-300">24.7 kWh</div>
                  <div className="text-xs text-green-200">+15% vs yesterday</div>
                </div>

                <div className="bg-blue-500 bg-opacity-20 border border-blue-500 rounded-lg p-4 text-center">
                  <h3 className="text-sm font-semibold text-blue-400 mb-2">CURRENT CONSUMPTION</h3>
                  <div className="text-3xl font-bold text-blue-300">3.2 kW</div>
                  <div className="text-xs text-blue-200">Normal usage</div>
                </div>

                <div className="bg-yellow-500 bg-opacity-20 border border-yellow-500 rounded-lg p-4 text-center">
                  <h3 className="text-sm font-semibold text-yellow-400 mb-2">MONTHLY SAVINGS</h3>
                  <div className="text-3xl font-bold text-yellow-300">₦85,420</div>
                  <div className="text-xs text-yellow-200">vs NEPA bills</div>
                </div>
              </div>

              <div className="bg-gray-700 rounded-lg p-6">
                <h3 className="text-lg font-semibold mb-4">7-Day Energy Production</h3>
                <div className="flex items-end justify-between h-32 space-x-2">
                  {[22, 28, 25, 30, 26, 32, 29].map((height, index) => (
                    <div key={index} className="flex-1 bg-gradient-to-t from-purple-500 to-purple-400 rounded-t" style={{height: `${height}%`}}></div>
                  ))}
                </div>
                <div className="flex justify-between mt-2 text-xs text-gray-400">
                  <span>Mon</span>
                  <span>Tue</span>
                  <span>Wed</span>
                  <span>Thu</span>
                  <span>Fri</span>
                  <span>Sat</span>
                  <span>Sun</span>
                </div>
              </div>

              <div className="text-center mt-8">
                <p className="text-gray-300 mb-4">Get real-time insights into your solar system's performance</p>
                <button className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg transition-colors">
                  View Full Dashboard
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Form Section */}
      <section id="contact" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-800 mb-4">Get Your Free Solar Quote</h2>
              <p className="text-gray-600">Ready to switch to solar? Send us your details and get a personalized quote within 24 hours.</p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-white p-8 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-6 text-gray-800">Request Free Quote</h3>
                <form className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Full Name *</label>
                    <input
                      type="text"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                      placeholder="Your full name"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number *</label>
                    <input
                      type="tel"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                      placeholder="080xxxxxxxx"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                    <input
                      type="email"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                      placeholder="your.email@example.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Location *</label>
                    <input
                      type="text"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                      placeholder="City, State"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Average Monthly Electricity Bill</label>
                    <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all">
                      <option>₦10,000 - ₦25,000</option>
                      <option>₦25,000 - ₦50,000</option>
                      <option>₦50,000 - ₦100,000</option>
                      <option>Above ₦100,000</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Message</label>
                    <textarea
                      rows={4}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                      placeholder="Tell us about your power requirements..."
                    ></textarea>
                  </div>
                  <button className="w-full bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-2">
                    <Send size={20} />
                    Get My Free Quote
                  </button>
                </form>
              </div>

              <div className="bg-purple-600 text-white p-8 rounded-lg">
                <h3 className="text-xl font-semibold mb-6">Contact Information</h3>
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <Phone className="w-5 h-5" />
                    <div>
                      <p className="font-medium">Call Us Now</p>
                      <p className="text-purple-200">08168216308</p>
                      <p className="text-purple-200">09028354365</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Mail className="w-5 h-5" />
                    <div>
                      <p className="font-medium">Email Us</p>
                      <p className="text-purple-200">sunworldtech19@gmail.com</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <MapPin className="w-5 h-5" />
                    <div>
                      <p className="font-medium">Visit Our Office</p>
                      <p className="text-purple-200">5 Oyetubo Street, Off Awolowo way, Opp Glowu Bus Stop, Ikeja, Lagos State</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <MessageCircle className="w-5 h-5" />
                    <div>
                      <p className="font-medium">WhatsApp</p>
                      <p className="text-purple-200">08168216308 - Available 24/7</p>
                    </div>
                  </div>
                </div>

                <div className="mt-8">
                  <h4 className="font-semibold mb-4">Business Hours</h4>
                  <div className="space-y-2 text-purple-200">
                    <p>Monday - Friday: 8:00 AM - 6:00 PM</p>
                    <p>Saturday: 9:00 AM - 4:00 PM</p>
                    <p>Sunday: Emergency calls only</p>
                  </div>
                </div>

                <div className="mt-8">
                  <h4 className="font-semibold mb-4">Why Choose Us?</h4>
                  <div className="space-y-2 text-purple-200 text-sm">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4" />
                      <span>Licensed & Certified Engineers</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4" />
                      <span>5-Year Comprehensive Warranty</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4" />
                      <span>24/7 Technical Support</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4" />
                      <span>Flexible Payment Plans</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-purple-600 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="bg-purple-500 text-white p-6 rounded-lg mb-8">
            <div className="grid md:grid-cols-3 gap-6">
              <div className="flex items-center gap-3">
                <MapPin size={20} />
                <div>
                  <h4 className="font-semibold">Head Office</h4>
                  <p className="text-sm">5 Oyetubo Street, Off Awolowo way, Opp Glowu Bus Stop, Ikeja, Lagos State</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Phone size={20} />
                <div>
                  <h4 className="font-semibold">Call Us</h4>
                  <p className="text-sm">08168216308 (Sales)</p>
                  <p className="text-sm">09028354365 (Technical)</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Mail size={20} />
                <div>
                  <h4 className="font-semibold">Email Us</h4>
                  <p className="text-sm">sunworldtech19@gmail.com</p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h4 className="font-semibold text-lg mb-4">Products</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-purple-200 transition-colors">Solar Panels</a></li>
                <li><a href="#" className="hover:text-purple-200 transition-colors">Inverters</a></li>
                <li><a href="#" className="hover:text-purple-200 transition-colors">Batteries</a></li>
                <li><a href="#" className="hover:text-purple-200 transition-colors">Stabilizers</a></li>
                <li><a href="#" className="hover:text-purple-200 transition-colors">Complete Systems</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-lg mb-4">Services</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-purple-200 transition-colors">System Design</a></li>
                <li><a href="#" className="hover:text-purple-200 transition-colors">Installation</a></li>
                <li><a href="#" className="hover:text-purple-200 transition-colors">Maintenance</a></li>
                <li><a href="#" className="hover:text-purple-200 transition-colors">Consultation</a></li>
                <li><a href="#" className="hover:text-purple-200 transition-colors">24/7 Support</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-lg mb-4">Newsletter</h4>
              <p className="text-sm mb-4">Get solar tips and exclusive offers</p>
              <div className="flex">
                <input
                  type="email"
                  placeholder="Your email"
                  className="flex-1 px-3 py-2 text-gray-800 rounded-l-lg focus:outline-none"
                />
                <button className="bg-orange-500 hover:bg-orange-600 px-4 py-2 rounded-r-lg transition-colors">
                  Subscribe
                </button>
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-lg mb-4">Sunworld Tech Support</h4>
              <p className="text-sm leading-relaxed mb-4">
                Nigeria's most trusted solar energy company. Empowering homes and businesses with reliable, sustainable power solutions since 2018.
              </p>
              <div className="flex gap-3 mt-4">
                <Facebook size={20} className="hover:text-purple-200 cursor-pointer transition-colors" />
                <Twitter size={20} className="hover:text-purple-200 cursor-pointer transition-colors" />
                <Instagram size={20} className="hover:text-purple-200 cursor-pointer transition-colors" />
                <Youtube size={20} className="hover:text-purple-200 cursor-pointer transition-colors" />
              </div>
            </div>
          </div>

          <div className="border-t border-purple-500 mt-8 pt-8 text-center text-sm">
            <p>Copyright © 2025 SUNWORLD TECH SUPPORT. All rights reserved. | Licensed by: Federal Ministry of Power | Certified by: NESREA</p>
          </div>
        </div>
      </footer>

      {/* Live Chat Widget */}
      <div className="fixed bottom-6 left-6 z-50">
        <div className="bg-white rounded-lg shadow-xl p-4 max-w-sm animate-slide-in-left">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-purple-600 rounded-full flex items-center justify-center">
              <MessageCircle className="w-5 h-5 text-white" />
            </div>
            <div>
              <h4 className="font-semibold text-gray-800">Need Help?</h4>
              <p className="text-xs text-gray-500">We're online now</p>
            </div>
            <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
          </div>
          <p className="text-sm text-gray-600 mb-3">
            Get instant answers about solar systems and pricing
          </p>
          <button className="w-full bg-purple-600 hover:bg-purple-700 text-white py-2 px-4 rounded-lg text-sm transition-colors">
            Start Chat
          </button>
        </div>
      </div>

      {/* Floating Action Buttons */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3">
        <button
          onClick={() => setShowCalculator(!showCalculator)}
          className="bg-green-600 hover:bg-green-700 text-white p-3 rounded-full shadow-lg transition-all duration-300 transform hover:scale-110 btn-ripple group"
          title="Solar Calculator"
        >
          <Calculator className="w-5 h-5 group-hover:rotate-12 transition-transform" />
        </button>
        <a
          href="tel:08168216308"
          className="bg-blue-500 hover:bg-blue-600 text-white p-3 rounded-full shadow-lg transition-all duration-300 transform hover:scale-110 btn-ripple group"
          title="Call Us"
        >
          <Phone className="w-5 h-5 group-hover:rotate-12 transition-transform" />
        </a>
        <a
          href="https://wa.me/2348168216308?text=Hello%20Sunworld%20Tech%20Support,%20I'm%20interested%20in%20your%20solar%20systems"
          target="_blank"
          rel="noopener noreferrer"
          className="bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg transition-all duration-300 transform hover:scale-110 animate-pulse btn-ripple group"
          title="WhatsApp Us"
        >
          <svg className="w-6 h-6 group-hover:scale-110 transition-transform" fill="currentColor" viewBox="0 0 24 24">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.886 3.488"/>
          </svg>
        </a>

        {/* Scroll to Top Button */}
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="bg-gray-600 hover:bg-gray-700 text-white p-3 rounded-full shadow-lg transition-all duration-300 transform hover:scale-110 btn-ripple group"
          title="Back to Top"
        >
          <ArrowRight className="w-5 h-5 -rotate-90 group-hover:-translate-y-1 transition-transform" />
        </button>
      </div>

      {/* Custom CSS for animations */}
      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        @keyframes fade-in {
          0% { opacity: 0; transform: translateY(20px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        @keyframes spin-slow {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        @keyframes slide-in-left {
          0% { opacity: 0; transform: translateX(-50px); }
          100% { opacity: 1; transform: translateX(0); }
        }
        @keyframes slide-in-right {
          0% { opacity: 0; transform: translateX(50px); }
          100% { opacity: 1; transform: translateX(0); }
        }
        @keyframes scale-in {
          0% { opacity: 0; transform: scale(0.8); }
          100% { opacity: 1; transform: scale(1); }
        }

        .animate-float {
          animation: float 3s ease-in-out infinite;
        }
        .animate-fade-in {
          animation: fade-in 1s ease-out;
        }
        .animate-spin-slow {
          animation: spin-slow 10s linear infinite;
        }
        .animate-slide-in-left {
          animation: slide-in-left 0.8s ease-out;
        }
        .animate-slide-in-right {
          animation: slide-in-right 0.8s ease-out;
        }
        .animate-scale-in {
          animation: scale-in 0.6s ease-out;
        }

        /* Smooth scrolling */
        html {
          scroll-behavior: smooth;
        }

        /* Loading state for images */
        img {
          transition: opacity 0.3s ease;
        }

        /* Enhanced hover effects */
        .hover-lift:hover {
          transform: translateY(-8px);
          box-shadow: 0 20px 40px rgba(147, 51, 234, 0.2);
        }

        /* Gradient text effect */
        .gradient-text {
          background: linear-gradient(135deg, #8b5cf6, #06b6d4);
          -webkit-background-clip: text;
          background-clip: text;
          -webkit-text-fill-color: transparent;
        }

        /* Card hover effects */
        .card-hover:hover {
          background: linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(6, 182, 212, 0.1));
          border: 1px solid rgba(139, 92, 246, 0.3);
        }

        /* Button ripple effect */
        .btn-ripple {
          position: relative;
          overflow: hidden;
        }

        .btn-ripple::before {
          content: '';
          position: absolute;
          top: 50%;
          left: 50%;
          width: 0;
          height: 0;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.3);
          transition: width 0.6s, height 0.6s;
          transform: translate(-50%, -50%);
        }

        .btn-ripple:active::before {
          width: 300px;
          height: 300px;
        }
      `}</style>
    </div>
  )
}
